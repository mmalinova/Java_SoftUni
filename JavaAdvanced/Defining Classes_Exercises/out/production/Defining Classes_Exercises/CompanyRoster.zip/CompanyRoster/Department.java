package CompanyRoster;

import java.util.ArrayList;
import java.util.List;

public class Department {
    List<Employees> employees = new ArrayList<>();

    public Department() {
        this.employees = new ArrayList<>();
    }


}
