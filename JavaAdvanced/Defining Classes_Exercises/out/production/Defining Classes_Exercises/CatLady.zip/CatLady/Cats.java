package CatLady;

public class Cats {
    private String name;

    public Cats(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
