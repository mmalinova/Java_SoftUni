package footballTeam;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        List<Team> teams = new ArrayList<>();

        String command = scan.nextLine();
        while (!"END".equals(command)) {
            String[] tokens = command.split(";");
            String teamName = tokens[1];
            switch (tokens[0]) {
                //•	"Team;<TeamName>" – add a new team
                //•	"Add;<TeamName>;<PlayerName>;<Endurance>;<Sprint>;<Dribble>;<Passing>;<Shooting>"
                // – add a new player to the team
                //•	"Remove;<TeamName>;<PlayerName>" – remove the player from the team
                //•	"Rating;<TeamName>" – print the team rating, rounded to a closest integer
                case "Team":
                    try {
                        Team team = new Team(teamName);
                        teams.add(team);
                    } catch (IllegalArgumentException ex) {
                        System.out.println(ex.getMessage());
                    }
                    break;
                case "Add":
                    String playerName = tokens[2];
                    int endurance = Integer.parseInt(tokens[3]);
                    int sprint = Integer.parseInt(tokens[4]);
                    int dribble = Integer.parseInt(tokens[5]);
                    int passing = Integer.parseInt(tokens[6]);
                    int shooting = Integer.parseInt(tokens[7]);
                    try {
                        Player player = new Player(playerName, endurance, sprint, dribble, passing, shooting);
                        boolean isAdd = false;
                        for (Team team : teams) {
                            if (team.getName().equals(teamName)) {
                                team.addPlayer(player);
                                isAdd = true;
                            }
                        }
                        if (!isAdd) {
                            System.out.println("Team " + teamName + " does not exist.");
                        }
                    } catch (IllegalArgumentException ex) {
                        System.out.println(ex.getMessage());
                    }
                    break;
                case "Remove":
                    playerName = tokens[2];
                    try {
                        boolean isExist = false;
                        for (Team team : teams) {
                            if (team.getName().equals(teamName)) {
                                team.removePlayer(playerName);
                                isExist = true;
                            }
                        }
                        if (!isExist) {
                            System.out.println("Team " + teamName + " does not exist.");
                        }
                    } catch (IllegalArgumentException ex) {
                        System.out.println(ex.getMessage());
                    }
                    break;
                case "Rating":
                    try {
                        boolean isExist = false;
                        for (Team teamToPrint : teams) {
                            if (teamToPrint.getName().equals(teamName)) {
                                isExist = true;
                                System.out.println(teamName + " - " + Math.round(teamToPrint.getRating()));
                            }
                        }
                        if (!isExist) {
                            System.out.println("Team " + teamName + " does not exist.");
                        }
                    } catch (IllegalArgumentException ex) {
                        System.out.println(ex.getMessage());
                    }
                    break;
            }
            command = scan.nextLine();
        }
    }
}